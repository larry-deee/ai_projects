"""
Test suite for the async Anthropic compatibility implementation.
"""